#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "../headers/functions.h"
#include "../headers/bit_field.h"
#include "../headers/stack.h"

int intLength(int number){
    if(number == 0){
        return 1;
    }
    int i = 0;
    while(number){
        number /= 10;
        i++;
    }
    return i;
}

int parseInt(char *str){
    int number = 0;
    for(int i = 0; str[i]; i++){
        if(str[i] >= 48 && str[i] <= 57){
            number = number*10 + str[i] - 48;
        }else{
            return number;
        }
    }
    return -1;
}

int main()
{

    int fd = open("a.txt", O_RDONLY);
    char *info     = my_readline(fd);
    int  rows      = parseInt(info);
    int  columns   = parseInt(info + intLength(rows) + 1);
    char full      = info[intLength(rows) + intLength(columns) + 1];
    char empty     = info[intLength(rows) + intLength(columns) + 2];
    char character = info[intLength(rows) + intLength(columns) + 3];
    char entry     = info[intLength(rows) + intLength(columns) + 4];
    char exit      = info[intLength(rows) + intLength(columns) + 5];
    free(info);
    printf("%d%d%c%c%c%c%c\n", rows, columns, full, empty, character, entry, exit);

    char info_string[6];
    info_string[0] = full;
    info_string[1] = empty;
    info_string[2] = entry;
    info_string[3] = exit;
    info_string[4] = character;
    info_string[5] = 0;

    //reopening because lseek 'pointer' is not on second line
    close(fd);
    fd = open("a.txt", O_RDONLY);

    int index = intLength(rows) + intLength(columns) + 6;

    //reading exactly number of chars that are on 1st row (basically skipping first line because we already have info)
    char *stringLine = readWithSize(fd, index);
    free(stringLine);

    bitField *bf = getNewBitField(columns*rows);

    stack *entries = getNewStack(4);
    stack *exits = getNewStack(16);
    int bitsIndex = 0;

    while(stringLine){
        stringLine = readWithSize(fd, columns);
        if(stringLine == NULL) break;
        copyToBitFieldFromStr(bf, stringLine, columns, bitsIndex, info_string, entries, exits);
        free(stringLine);
        bitsIndex += columns;
    }

    printBitField(bf, rows, columns, info_string);


    //frees..
    freeBitField(bf);
    freeStack(entries);
    freeStack(exits);
    close(fd);
    return 0;
}
