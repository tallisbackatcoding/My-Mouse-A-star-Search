#include <stdlib.h>
#include <stdio.h>
#include "../headers/bit_field.h"

bitField* getNewBitField(int size){
    bitField *newBitField = malloc(sizeof(bitField));
    //we are using 32bit ints and allocate 2 times more bits since we need 2 of them for every cell
    int arraySize = size/16 + 1;
    newBitField->field = malloc(sizeof(int)*arraySize);
    printf("array size %d \n", arraySize);
    return newBitField;
}

void SetBit(bitField *bf, int k){
     (bf->field[(k/32)] |= (1 << (k%32)));
}

void ClearBit(bitField *bf, int k){
    bf->field[(k/32)] &= ~(1 << (k%32)) ;
}

int TestBit(bitField *bf, int k){
    return bf->field[(k/32)] & (1 << (k%32));
}

void Set2Bits(bitField *bf, int k, int value /*from 0 to 3 */){
    k *= 2;
    if(value == 0){
        ClearBit(bf, k);
        ClearBit(bf, k+1);
    }
    else if(value == 1){
        ClearBit(bf, k);
        SetBit(bf, k+1);
    }else if(value == 2){
        SetBit(bf, k);
        ClearBit(bf, k+1);
    }else if(value == 3){
        SetBit(bf, k);
        SetBit(bf, k+1);
    }
}

int Test2Bits(bitField *bf, int k){
    k *= 2;
    if(TestBit(bf, k) && TestBit(bf, k+1)){
        return 3;
    }else if(TestBit(bf, k) && !TestBit(bf, k+1)){
        return 2;
    }else if(!TestBit(bf, k) && TestBit(bf, k+1)){
        return 1;
    }else{
        return 0;
    }
}

void copyToBitFieldFromStr(bitField *bf, char *str, int strSize, int bitsIndex, char info_string[], stack *entries, stack* exits){
    char full, empty, entry, exit;
    full  = info_string[0];
    empty = info_string[1];
    entry = info_string[2];
    exit  = info_string[3];

    for(int i = 0; i < strSize; i++){
        int k = bitsIndex+i;
        if(str[i] == empty){
            Set2Bits(bf, k, 0);
        }
        else if(str[i] == full){
            Set2Bits(bf, k, 1);
        }else if(str[i] == entry){
            push(entries, i);
            push(entries, bitsIndex/10);
            Set2Bits(bf, k, 2);
        }else if(str[i] == exit){
            push(exits, i);
            push(exits, bitsIndex/10);
            Set2Bits(bf, k, 3);
        }
    }
}

void printBitField(bitField *bf, int rows, int columns, char info_string[]){
    char full, empty, entry, exit;
    full  = info_string[0];
    empty = info_string[1];
    entry = info_string[2];
    exit  = info_string[3];
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < columns; j++){
            int k = columns*i + j;
            int testBits = Test2Bits(bf, k);
            if(testBits == 3){
                printf("%c", exit);
            }else if(testBits == 2){
                printf("%c", entry);
            }else if(testBits == 1){
                printf("%c", full);
            }else{
                printf("%c", empty);
            }
        }
        printf("\n");
    }
}

void freeBitField(bitField *bf){
    free(bf->field);
    free(bf);
}

