#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED


int my_strlen(char *s)
#endif
